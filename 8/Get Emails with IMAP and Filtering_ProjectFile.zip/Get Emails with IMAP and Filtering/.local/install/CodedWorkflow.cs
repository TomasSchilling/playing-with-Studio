using UiPath.CodedWorkflows;

namespace GetEmailswithIMAPandFiltering
{
    public partial class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}